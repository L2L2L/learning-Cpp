// conditional.h by Bill Weinman <http://bw.org/>
#ifndef CONDITIONAL_H_
#define CONDITIONAL_H_

#ifdef FOO

#define NUMBER 47

#else

#define NUMBER 2

#endif

#endif /* CONDITIONAL_H_ */
