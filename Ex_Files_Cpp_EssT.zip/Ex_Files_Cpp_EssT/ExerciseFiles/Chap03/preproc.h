// preproc.h by Bill Weinman <http://bw.org/>

#ifndef PREPROC_H_
#define PREPROC_H_

#define ONE 1

const int _iOne = 1;
const char _sOne[] = "one";

#endif /* PREPROC_H_ */
